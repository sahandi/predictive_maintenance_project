## Dataset

The dataset used in this project is the **FD001** subset of the **Turbofan Engine Degradation Simulation Data Set** from the [NASA Prognostics Data Repository](https://www.nasa.gov/content/prognostics-center-of-excellence-data-set-repository).

### Included Files in `data.zip`:
- `train_FD001.txt`: The dataset used for training and evaluation.
- `nasa_readme.txt`: Documentation from NASA explaining the dataset structure.
- `README.md`: Documentation for this project.

### Download Instructions:

If you wish to download the dataset directly from NASA, you can visit the following link:
[NASA Prognostics Data Repository - Turbofan Engine Degradation Simulation Data Set](https://www.nasa.gov/content/prognostics-center-of-excellence-data-set-repository)

Alternatively, you can use the included dataset by unzipping the provided `data.zip` file.

### Instructions to Unzip:

After cloning the repository, unzip the dataset with the following command:

```bash
unzip data.zip -d data/
